# scai
Multi-Character chat client for Ollama
